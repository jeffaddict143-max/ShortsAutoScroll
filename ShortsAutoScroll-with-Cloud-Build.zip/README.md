# Shorts Auto Scroll (Android starter project)

This is a Kotlin Android Studio starter app with:
- Timer mode: swipe every 30, 45, or 60 seconds.
- Smart mode: attempts to detect a near-end accessibility progress value, with the selected interval as a fallback.
- Start/Stop controls in the app.

## Build
1. Install Android Studio (current stable).
2. Open this folder as a project.
3. Let Gradle sync.
4. Connect an Android phone and press Run, or build an APK from Build > Build Bundle(s) / APK(s) > Build APK(s).

## Enable
1. Open the app.
2. Select a mode and interval, then Save settings.
3. Tap Open Accessibility Settings.
4. Enable "Shorts Auto Scroll Controller".
5. Return to the app and tap Start Auto Scroll.
6. Open YouTube Shorts.

## Important limitations
- This is an unofficial helper; it does not modify or integrate with YouTube.
- Android requires explicit accessibility permission because the app performs swipe gestures.
- YouTube may not expose a reliable video progress indicator to accessibility services. In that case Smart Mode falls back to the chosen interval; it cannot guarantee an exact end-of-video swipe.
- Test with Timer Mode first. Stop the controller before using other apps.
- No root access is required.

## Privacy
The starter code does not request internet permission and does not send data anywhere. Accessibility access is used only to inspect the active view hierarchy for progress and dispatch the swipe gesture when enabled.

## Build an APK without installing Android Studio
This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
1. Create a GitHub repository and upload the extracted project files.
2. Open the repository's Actions tab.
3. Select "Build Android APK" and choose "Run workflow" (or push to `main`).
4. When the workflow finishes, open its run and download the `ShortsAutoScroll-debug-apk` artifact.
5. Extract the artifact ZIP to get `app-debug.apk`.
