package com.example.shortsautoscroll

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("shorts_auto", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 28)
            setBackgroundColor(0xFFF7F8FA.toInt())
        }
        fun addText(value: String, size: Float, bold: Boolean = false) {
            root.addView(TextView(this).apply {
                text = value
                textSize = size
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(0xFF172033.toInt())
                setPadding(0, 8, 0, 12)
            })
        }
        fun addButton(label: String, action: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = 10
            })
        }

        addText("Shorts Auto Scroll", 26f, true)
        addText("Hands-free YouTube Shorts controller", 15f)
        addText("1. Choose mode", 18f, true)

        val mode = Spinner(this)
        mode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Smart Mode (detect video end)", "Timer Mode"))
        mode.setSelection(if (prefs.getString("mode", "smart") == "timer") 1 else 0)
        root.addView(mode)

        addText("2. Timer / fallback interval", 18f, true)
        val interval = Spinner(this)
        interval.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("30 seconds", "45 seconds", "60 seconds"))
        val savedInterval = prefs.getInt("interval", 45)
        interval.setSelection(listOf(30,45,60).indexOf(savedInterval).coerceAtLeast(0))
        root.addView(interval)

        addText("3. Enable the controller", 18f, true)
        addText("Android requires you to manually enable the accessibility service. This permission lets the app perform swipe gestures.", 14f)

        addButton("Open Accessibility Settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton("Save settings") {
            val selectedMode = if (mode.selectedItemPosition == 1) "timer" else "smart"
            val seconds = listOf(30,45,60)[interval.selectedItemPosition]
            prefs.edit().putString("mode", selectedMode).putInt("interval", seconds).apply()
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
        }
        addButton("Start Auto Scroll") {
            val selectedMode = if (mode.selectedItemPosition == 1) "timer" else "smart"
            val seconds = listOf(30,45,60)[interval.selectedItemPosition]
            prefs.edit().putString("mode", selectedMode).putInt("interval", seconds).putBoolean("enabled", true).apply()
            Toast.makeText(this, "Enabled. Open YouTube Shorts.", Toast.LENGTH_LONG).show()
        }
        addButton("Stop Auto Scroll") {
            prefs.edit().putBoolean("enabled", false).apply()
            Toast.makeText(this, "Auto Scroll stopped", Toast.LENGTH_SHORT).show()
        }

        addText("How to use", 18f, true)
        addText("Open this app → choose Smart or Timer → save → enable the accessibility service → tap Start → open YouTube Shorts. Return here and tap Stop whenever you want to pause.", 14f)
        addText("Note: Smart detection depends on whether YouTube exposes video progress to Android accessibility. If it does not, the selected fallback interval is used.", 13f)
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
