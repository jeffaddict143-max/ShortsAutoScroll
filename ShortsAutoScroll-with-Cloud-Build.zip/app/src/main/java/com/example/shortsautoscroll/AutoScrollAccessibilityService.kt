package com.example.shortsautoscroll

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class AutoScrollAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastSwipeAt = 0L
    private var smartCandidateSince = 0L
    private var lastSmartProgress = -1f

    private val timerTick = object : Runnable {
        override fun run() {
            if (!isEnabled()) return
            val prefs = getSharedPreferences("shorts_auto", MODE_PRIVATE)
            val mode = prefs.getString("mode", "smart")
            val intervalMs = prefs.getInt("interval", 45) * 1000L
            val now = System.currentTimeMillis()
            if (mode == "timer") {
                if (now - lastSwipeAt >= intervalMs) swipeNext()
            } else {
                // Fallback if no usable progress bar is exposed by YouTube.
                if (now - lastSwipeAt >= intervalMs && smartCandidateSince == 0L) swipeNext()
            }
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.removeCallbacks(timerTick)
        handler.post(timerTick)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!isEnabled()) return
        val prefs = getSharedPreferences("shorts_auto", MODE_PRIVATE)
        if (prefs.getString("mode", "smart") != "smart") return
        val root = rootInActiveWindow ?: return
        val progress = findNearEndProgress(root)
        root.recycle()
        if (progress != null) {
            val now = System.currentTimeMillis()
            if (progress >= 0.985f) {
                if (smartCandidateSince == 0L) smartCandidateSince = now
                // Require the near-end state to remain visible briefly to avoid false triggers.
                if (now - smartCandidateSince >= 700L && now - lastSwipeAt > 5000L) {
                    swipeNext()
                }
            } else {
                smartCandidateSince = 0L
                lastSmartProgress = progress
            }
        }
    }

    private fun findNearEndProgress(node: AccessibilityNodeInfo): Float? {
        val range = node.rangeInfo
        if (range != null && range.type == AccessibilityNodeInfo.RangeInfo.RANGE_TYPE_PERCENT) {
            val max = range.max
            if (max > 0f) return (range.current / max).coerceIn(0f, 1f)
        }
        if (node.className?.toString()?.contains("SeekBar", true) == true) {
            val desc = (node.contentDescription?.toString() ?: node.text?.toString() ?: "").lowercase(Locale.ROOT)
            // Some app versions expose a time label but not a normalized progress value.
            val timeMatch = Regex("(\\d+):(\\d+)\\s*/\\s*(\\d+):(\\d+)").find(desc)
            if (timeMatch != null) {
                val v = timeMatch.groupValues
                val current = v[1].toInt() * 60 + v[2].toInt()
                val total = v[3].toInt() * 60 + v[4].toInt()
                if (total > 0) return current.toFloat() / total
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findNearEndProgress(child)
            child.recycle()
            if (found != null) return found
        }
        return null
    }

    private fun isEnabled(): Boolean =
        getSharedPreferences("shorts_auto", MODE_PRIVATE).getBoolean("enabled", false)

    private fun swipeNext() {
        if (!isEnabled()) return
        val now = System.currentTimeMillis()
        if (now - lastSwipeAt < 5000L) return
        lastSwipeAt = now
        smartCandidateSince = 0L
        val dm = resources.displayMetrics
        val x = dm.widthPixels * 0.5f
        val startY = dm.heightPixels * 0.78f
        val endY = dm.heightPixels * 0.25f
        val path = Path().apply { moveTo(x, startY); lineTo(x, endY) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 80L, 280L))
            .build()
        dispatchGesture(gesture, null, null)
    }

    override fun onInterrupt() {
        getSharedPreferences("shorts_auto", MODE_PRIVATE).edit().putBoolean("enabled", false).apply()
        handler.removeCallbacks(timerTick)
    }

    override fun onDestroy() {
        handler.removeCallbacks(timerTick)
        super.onDestroy()
    }
}
